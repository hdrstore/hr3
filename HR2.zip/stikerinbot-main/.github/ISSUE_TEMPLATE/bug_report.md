---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Describe the bug**
Deskripsi lengkap mengenai bug

**To Reproduce**
Cara Mendapatkan Bug:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**Expected behavior**
Apa yang anda harapkan terjadi sebenarnya.

**Screenshots**
Jika bisa tambahkan gambar agar mempermudah menjelaskan bug.

**Desktop (please complete the following information):**
 - Browser [e.g. chrome, safari]
 - Version [e.g. 22]

**Smartphone (please complete the following information):**
 - Whatsapp Version : [e.g. 2.21.19.21] if using Whatsapp Mod, Type 8.22.29.3
 - Device: [e.g. iPhone6]
 - OS: [e.g. iOS8.1]

**Additional context**
Tambahkan beberapa konteks tentang bug (Jika Perlu).
