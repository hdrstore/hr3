let handler = async (m, { conn }) => {
  conn.sendFile(m.chat, API('mel', '/asupan', {}, 'apikey'), 'asupan.mp4', '© HR Bot')
}
handler.help = ['asupan']
handler.tags = ['fun']
handler.command = /^(asupan)$/i
handler.register = true

module.exports = handler
